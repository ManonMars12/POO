package package_1;

import java.util.ArrayList;

public class Acteur {
	
	private String nom; 
	private ArrayList<Ressource> a_joue_dans; 
	
	public Acteur(String nom) {
		this.nom=nom;
		this.a_joue_dans = new ArrayList<>(); 
	}

	public void a_joue(Ressource ressource) {
		a_joue_dans.add(ressource); 
	}
	

}

