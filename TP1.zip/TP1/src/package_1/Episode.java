package package_1;

public class Episode {
	
	private String nom;
	private int duree; //duree en heure
	private Serie serie;
	
	public Episode(String nom, int duree, Serie serie) {
		this.nom=nom; 
		this.duree=duree; 
		this.serie=serie;
	}
	

}
