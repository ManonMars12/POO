package package_1;

import java.util.ArrayList;

public class Film extends Ressource{
	
	
	public Film(String titre, Producteur createur, int duree, String affiche, String synopsis,String categorie) {
		super(titre, createur, duree, affiche, synopsis,categorie);
		

}
	

	
}
