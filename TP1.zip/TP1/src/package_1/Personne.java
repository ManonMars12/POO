package package_1;

public class Personne {
	
	private String nom;
	private static int id;
	private static int INIT_ID=1;
	
	public Personne(String nom) {
		this.nom=nom;
		this.id=INIT_ID; 
		INIT_ID= INIT_ID+1; 
		
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public static int getId() {
		return id;
	}

	

}
