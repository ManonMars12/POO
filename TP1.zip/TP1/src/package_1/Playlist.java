package package_1;

import java.util.ArrayList;

public class Playlist {
	
	private String titre;
	private int duree; //duree en heure 
	private  boolean publique; 
	private ArrayList<Ressource> contient; 
	private Utilisateur createur; 
	private ArrayList<Utilisateur> visionneurs; 
	
	public Playlist(String titre, boolean publique, Utilisateur createur) {
		this.titre=titre; 
		this.publique=publique; 
		this.createur=createur; 
		this.contient = new ArrayList<>(); 
		this.visionneurs = new ArrayList<>();
		
	}
	
	public void add_visionneur(Utilisateur visionneur) {
		this.visionneurs.add(visionneur);
	}
	
	public void add_ressource(Ressource res) {
		this.contient.add(res);
	}
	
	public void setPublique(boolean publique) {
		this.publique=publique; 
	}

}
