package package_1;

import java.util.ArrayList; 

public class Primeflix {
	
	private ArrayList <Serie> series; 
	private ArrayList <Film> films;
	private ArrayList <Utilisateur> utilisateurs;
	private ArrayList <Producteur> producteurs;
	
	public Primeflix() {
		this.series= new ArrayList<>(); 
		this.films= new ArrayList<>(); 
		this.utilisateurs= new ArrayList<>(); 
		this.producteurs= new ArrayList<>();
	}
	
	public void add_serie(Serie une_serie){
		series.add(une_serie); 
		
	}
	
	public void add_film(Film un_film){
		films.add(un_film); 
		
	}
	
	public void add_uti(Utilisateur un_uti){
		utilisateurs.add(un_uti); 
		
	}
	
	public void add_prod(Producteur un_prod){
		producteurs.add(un_prod); 
		
	}
	
	public void supp_serie(Serie une_serie){
		series.remove(une_serie); 
		
	}
	
	public void supp_film(Film un_film){
		films.remove(un_film); 
		
	}

}
