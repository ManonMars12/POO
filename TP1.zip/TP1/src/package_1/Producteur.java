package package_1;

import java.util.ArrayList;

public class Producteur extends Personne {
	
	private ArrayList<Serie> series;
	private ArrayList<Film> films;
	private double remuneration; 
	
	public Producteur(String nom) {
		super(nom); 
		this.remuneration=0;
		this.series= new ArrayList<>(); 
		this.films= new ArrayList<>(); 
	}
	
	
	public void produire(Ressource ressource) {
		if (ressource instanceof Serie) {
			Serie serie = (Serie) ressource;
			this.series.add(serie); 
		}
		if (ressource instanceof Film) {
			Film film = (Film) ressource;
			this.films.add(film); 
		}
		
	}
	
	public double getRemuneration() {
		return remuneration;
	}



	public void gagner_argent(double somme) {
		this.remuneration=remuneration+somme; 
	}
	
	
}
