package package_1;

import java.util.ArrayList;

public class Ressource {
	
	private String titre;
	private Producteur createur; 
	private int duree; //Duree en heure
	private String affiche; 
	private String synopsis; 
	private ArrayList<Acteur> casting;  
	private String categorie; 


	
	
	public Ressource(String titre, Producteur createur, int duree, String affiche, String synopsis, String categorie) {
		
		this.titre=titre; 
		this.createur=createur;
		this.duree=duree; 
		this.affiche=affiche;
		this.synopsis=synopsis;
		this.categorie=categorie;
		this.casting= new ArrayList<>(); 

		
		
	}




	public String getTitre() {
		return titre;
	}




	public void setTitre(String titre) {
		this.titre = titre;
	}




	public Producteur getCreateur() {
		return createur;
	}




	public void setCreateur(Producteur createur) {
		this.createur = createur;
	}




	public int getDuree() {
		return duree;
	}




	public void setDuree(int duree) {
		this.duree = duree;
	}




	public String getAffiche() {
		return affiche;
	}




	public void setAffiche(String affiche) {
		this.affiche = affiche;
	}




	public String getSynopsis() {
		return synopsis;
	}




	public void setSynopsis(String synopsis) {
		this.synopsis = synopsis;
	}




	public ArrayList<Acteur> getCasting() {
		return casting;
	}




	public void setCasting(ArrayList<Acteur> casting) {
		this.casting = casting;
	}




	public String getCategorie() {
		return categorie;
	}




	public void setCategorie(String categorie) {
		this.categorie = categorie;
	}
	
	public void add_casting(Acteur acteur) {
		this.getCasting().add(acteur);
		
	}
	

}
