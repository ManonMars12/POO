package package_1;

import java.util.ArrayList;

public class Saison {

	private String nom;
	private Serie serie;
	private int nb_ep;
	private ArrayList<Episode> episodes;
	
	public Saison(String nom, int nb_ep, Serie serie) {
		this.nom=nom; 
		this.nb_ep=nb_ep; 
		this.serie=serie;
		this.episodes = new ArrayList<>();
	}
	
	
	public void add_episode(Episode ep) {
		this.episodes.add(ep);
	}


	public ArrayList<Episode> getEpisodes() {
		return episodes;
	}


	public void setEpisodes(ArrayList<Episode> episodes) {
		this.episodes = episodes;
	}
}
