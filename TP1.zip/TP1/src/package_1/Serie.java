package package_1;

import java.util.ArrayList;

public class Serie extends Ressource{
	
	private ArrayList<Saison> saisons; 
	private String categorie; 
	
	public Serie(String titre, Producteur createur, int duree, String affiche, String synopsis,String categorie) {
		super(titre, createur, duree, affiche, synopsis,categorie);
		this.saisons= new ArrayList<>(); 
		this.categorie=categorie; 
		
		
		
	}
	
	public void add_saison(Saison saison) {
		saisons.add(saison);
		
	}

	public ArrayList<Saison> getSaisons() {
		return saisons;
	}

	public void setSaisons(ArrayList<Saison> saisons) {
		this.saisons = saisons;
	}
	
	
	
	

}
