package package_1;

import java.util.ArrayList;

public class Utilisateur extends Personne{
	
	private double total_a_payer;
	private boolean premium; 
	private String prenom; 
	private int age; 
	private String login; 
	private String mdp; 
	
	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getMdp() {
		return mdp;
	}

	public void setMdp(String mdp) {
		this.mdp = mdp;
	}

	public Utilisateur(String nom, boolean premium) {
		super(nom); 
		this.premium=premium;
		
	}

	public double getTotal_a_payer() {
		return total_a_payer;
	}



	public boolean isPremium() {
		return premium;
	}

	public void setPremium(boolean premium) {
		this.premium = premium;
	}
	
	public void visionner(Ressource ressource) {
		double duree = ressource.getDuree(); 
		if (premium) {
			double a_payer= duree*0.90; 
			this.total_a_payer=a_payer;
			double remu_prod=a_payer*0.66;
			ressource.getCreateur().gagner_argent(remu_prod);
			
		}
		else {
			double a_payer= duree*0.50; 
			this.total_a_payer=a_payer;
			double remu_prod=a_payer*0.66;
			ressource.getCreateur().gagner_argent(remu_prod);
			
		}
		
		
		
		
	}
	
	public void create_playlist(ArrayList<Ressource> res, String titre, boolean publique, Utilisateur createur) {
        Playlist p1 = new Playlist(titre, publique, createur);
        for (Ressource r : res) {
            p1.add_ressource(r);
        }
	
		
		
	}
	

}
