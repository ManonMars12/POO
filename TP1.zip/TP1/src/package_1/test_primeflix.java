package package_1;

public class test_primeflix {

	public static void main(String[] args) {
		
		Utilisateur p1 = new Utilisateur("toto", true);
		Utilisateur p2 = new Utilisateur("titi", false);
		Producteur personne1 = new Producteur ("moi");
		
		Serie s1 = new Serie("Serie", personne1, 4, "mon affiche", "il se passe des trucs", "horreur");
	
	
		System.out.println(p1.getTotal_a_payer());
		System.out.println(p2.getTotal_a_payer());

		p1.visionner(s1); 
		p2.visionner(s1);
		
		System.out.println(p1.getTotal_a_payer());
		System.out.println(p2.getTotal_a_payer());
		
		System.out.println(personne1.getRemuneration());
		
		
		Serie s2 = new Serie("une autre serie", personne1, 2, "affiche", "synopsis", "comedie"); 
		personne1.produire(s2);
		
		p1.setPrenom("toto");
		p1.setAge(18);
		p1.setMdp("ABCD1234"); 
		p1.setLogin("toto1234");
			
		

		Film f1 = new Film ("un film", personne1, 3, "affiche", "synopsis", "documentaire"); 
		
		Playlist playlist1= new Playlist("Playlist 1", true, p1); 
		playlist1.add_ressource(s1); 
		playlist1.add_ressource(s2); 
		playlist1.add_ressource(f1); 
		
	
	}
	

}
